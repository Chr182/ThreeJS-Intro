//npx vite -- to start use it in terminal
import * as THREE from 'three';

const scene = new THREE.Scene();
const aspectRatio = window.innerWidth / window.innerHeight;
const cameraWidth = 150;
const cameraHeight = cameraWidth / aspectRatio;
var speedz = 0;
var speedx = 0;

const camera = new THREE.OrthographicCamera(
  cameraWidth / -2, // left
  cameraWidth / 2, // right
  cameraHeight / 2, // top
  cameraHeight / -2, // bottom
  0, // near plane
  1000 // far plane
);
camera.position.set(200, 200, 200);
camera.lookAt(0, 0, 0);

const renderer = new THREE.WebGLRenderer();
renderer.setSize( window.innerWidth, window.innerHeight );
document.body.appendChild( renderer.domElement );

const plane = new THREE.Group()

var geometry = new THREE.BoxGeometry( 2, 2, 12 );
var material = new THREE.MeshPhongMaterial( { color: 0xcc99ff } );
var main = new THREE.Mesh( geometry, material );
main.position.z = -2
plane.add( main );

geometry = new THREE.BoxGeometry( 2, 2, 4 );
material = new THREE.MeshPhongMaterial( { color: 0xcc99ff } );
var wing = new THREE.Mesh( geometry, material);
wing.position.x = 2
wing.position.z = -2
plane.add(wing)
var wing2 = new THREE.Mesh( geometry, material);
wing2.position.x = -2
wing2.position.z = -2
plane.add(wing2)

geometry = new THREE.BoxGeometry( 10, 2, 2 );
material = new THREE.MeshPhongMaterial( { color: 0xcc99ff } );
var mainwing = new THREE.Mesh( geometry, material);
plane.add( mainwing )

geometry = new THREE.BoxGeometry( 2, 2, 1 );
material = new THREE.MeshPhongMaterial( { color: 0x383838 } );
var bay = new THREE.Mesh( geometry, material);
bay.position.z = -8.5
plane.add( bay )

scene.add( plane )

function shoot() {
    let bullet = new THREE.Mesh(new THREE.BoxGeometry(1,1,1), new THREE.MeshPhongMaterial( { color: 0x383838 }))
    
}

const light = new THREE.AmbientLight( 0x404040, 1 ); // applies light to all objests, lambet and phong can't be seen without light sources
const directionalLight = new THREE.DirectionalLight( 0xcc99ff, 0.5 ); //like a sun, type of shit
directionalLight.position.set(200, 500, 300)
scene.add( light );
scene.add( directionalLight );

document.onkeydown = KeyCheck;
function KeyCheck() {
    var KeyBind = event.keyCode;
    var square = Math.PI / 2
    var deg = (plane.rotation.y/square) * 90 ;
    var rad = (deg/360 * 6.28)
    switch(KeyBind) { //90 degrees = 1.5708
        case 87: //w
            speedz -=(Math.cos(rad) * 0.1);
            speedx -=(Math.sin(rad) * 0.1);
            break;
        case 83: //s
            speedz +=(Math.cos(rad) * 0.1);
            speedx +=(Math.sin(rad) * 0.1);
            break;
        case 37: //ArrowLeft
            plane.rotation.y +=0.1;
            speedz -= speedx * (Math.cos(0.1/square) * 0.1);
            speedx += speedz * (Math.cos(0.1/square) * 0.1);
            break;
        case 39: //ArrowRight
            plane.rotation.y -=0.1;
            speedz += speedx * (Math.cos(0.1/square) * 0.1);
            speedx -= speedz * (Math.cos(0.1/square) * 0.1);
            break;
        case 67: //c
            console.log(
                "plane y rotation:", deg, "\n",
                "plane y radian:", rad, "\n",
                "plane x speed:", speedx, "\n",
                "plane z speed:", speedz, "\n"
            );
            break;
        case 70:
            shoot();
            break;
    }
}

function animate() {
	renderer.render( scene, camera );
    plane.position.z += speedz;
    plane.position.x += speedx;
    camera.lookAt(plane.position.x, plane.position.y, plane.position.z);
}
renderer.setAnimationLoop( animate );